Image Source:
Photo by Jairph on Unsplash: https://unsplash.com/@jairph?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash